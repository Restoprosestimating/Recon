# Restopros Recon Tracker

Turns an **Xactimate Internal TAM PDF** into a Restopros cost / royalty / profitability workbook (same model as the 600 Elgin recon sheet).

## Required upload

The uploaded file **must be an Xactimate PDF Internal TAM report** with **all 7 print selections checked**:

1. Coversheet
2. Line item detail
3. Summary
4. Recap by room
5. Recap by category
6. Labor breakdown
7. Sketch / Grand total areas

In Xactimate: **Documents → Reports → Report type = Internal TAM → Print selections → check all → export PDF**.

Final Draft, Scope, Abbreviated, or a TAM printed without Labor breakdown will be rejected.

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5055

## Deploy (public link)

Grok cannot host this. Use Render (easiest) or any Procfile host.

### Render

1. Put this folder in a GitHub repo.
2. [Render.com](https://render.com) → New → Web Service → connect that repo.
3. Render reads `render.yaml`. Confirm:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --timeout 120`
4. Deploy. You get a URL such as `https://restopros-recon-tracker.onrender.com`.

### Railway / Fly / other

`Procfile` is already in the folder:

```
web: gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --timeout 120
```

Set environment variable `RECON_SECRET` to a long random string. Optional: `RECON_DATA_DIR=/tmp` (used on Render free tier).

## Defaults

| Assumption | Default |
|---|---|
| Supervisor gross | $30/hr (CLN-S / supervisory) |
| Worker gross | $22/hr (all other TAM labor codes) |
| Burden | 18% |
| Royalty | 8% of negotiated price |
| Contingency | 5% of materials + equipment |

Negotiated price defaults to Replacement Cost Value and is the yellow box on the Summary tab.
